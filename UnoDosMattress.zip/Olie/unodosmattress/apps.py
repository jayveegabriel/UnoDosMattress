from django.apps import AppConfig


class UnodosmattressConfig(AppConfig):
    name = 'unodosmattress'
